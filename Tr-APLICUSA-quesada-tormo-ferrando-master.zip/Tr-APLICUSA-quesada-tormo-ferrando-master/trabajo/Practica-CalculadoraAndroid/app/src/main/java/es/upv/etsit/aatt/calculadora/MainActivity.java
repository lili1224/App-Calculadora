package es.upv.etsit.aatt.calculadora;

import androidx.appcompat.app.AppCompatActivity;

import android.content.pm.ActivityInfo;
import android.os.Bundle;
import android.view.Display;
import android.view.View;
import android.widget.TextView;

import java.text.DecimalFormat;

public class MainActivity extends AppCompatActivity {

    /** Clase enumerada de tipos de operacion general */
    enum OPERACION { SUMAR, RESTAR, MULTIPLICAR, DIVIDIR, IGUAL, BORRADO, SIGNO, ELEVAR, RAIZ}
    /** Operacion anterior pendiente de realizar */
    OPERACION OP_ANT;

    /** Clase enumerada de estados de la calculadora */
    enum ESTADOS {INIC, NUMERO, OPERACION}
    /** Estado en el que se está */
    ESTADOS estado;

    /** Acumulador de operaciones: operando1 */
    double acumulador;

    /** operando2 de las operaciones en format String para escribir en pantalla y double para hacer operaciones */
    String operando2_str;
    double operando2;

    /** TextView para escribir resultados y operandos en pantalla */
    TextView display;

    /** Para fijar formato en salida de pantalla */
    DecimalFormat df;

    private boolean punto = false;

    private String cero = "0.";

    private boolean LastClickClear = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_PORTRAIT);

        // Enlazamos el TextView en variable display para pantalla de calculadora
        display = (TextView)findViewById(R.id.display);

        // Formato de salida de los resulados
        df = new DecimalFormat("#.#############");

        // Inicialización de calculadora
        aINIC();
    }

    /**
     * Inicialización
     */
    private void aINIC() {

        operando2_str   = "";     // String de formación de operando2 vacío
        display.setText(cero);    // Visualización en TextView display
        operando2 = 0.;           // operando2 double
        acumulador = 0.;          // valor inicial del acumulador
        OP_ANT = OPERACION.IGUAL; // operacion_anterior pendiente: igual
        estado = ESTADOS.INIC;    // estamos en el estado INIC.
        punto = false;
    }

    /**
     * Método de call-back ejecutado cuando se clica alguno de los TextView en los que se
     * ha programado el atributo android:onClick con alPulsarTecla.
     *
     * A partir del TextView tecla se extrae su id y se compara con todos los posibles id mediante la
     * clase R. Las comparaciones se hacen en una estructura switch, agrupándose los distintos cases
     * según funcionalidad común
     *
     * @param tecla TextView que ha sido clicado
     */

    public void alPulsarTecla(View tecla){

        int id = tecla.getId(); // id de la tecla pulsada

        // Comparación del id de la tecla pulsada con los id de dígitos decimales, punto decimal, operaciones, ...
        switch(id) {

            case R.id.b_punto:
                if (punto == false){
                    punto = true;
                    if (operando2_str.equals("")){
                        operando2_str = "0";
                    }
                } else {
                    return;
                }
            case R.id.b0:
            case R.id.b1:
            case R.id.b2:
            case R.id.b3:
            case R.id.b4:
            case R.id.b5:
            case R.id.b6:
            case R.id.b7:
            case R.id.b8:
            case R.id.b9:
                operando2_str += ((TextView)tecla).getText().toString();  // acumulación de digito o punto
                operando2 = miStringToDouble( operando2_str ); // conversión de String a double
                display.setText(operando2_str); // Visualización
                estado = ESTADOS.NUMERO; // estamos en estado NUMERO
                LastClickClear = false;
                break;

            case R.id.b_mas:
            case R.id.b_menos:
            case R.id.b_por:
            case R.id.b_div:
            case R.id.b_elevar:
            case R.id.b_raiz:
                if (OP_ANT != OPERACION.IGUAL){
                    OP_ANT = OPERACION.IGUAL;
                }
            case R.id.b_igual:
                acumulador = operar(acumulador, OP_ANT, operando2); // opera acumulador y operando2 según la operacion anterior (OP_ANT) pendiente
                display.setText( miDoubleToString(acumulador) ); // visualiza el resultado (acumulador)
                // guarda operacion actual en la operacion anterior (OP_ANT)
                switch(id) {
                    case R.id.b_mas:   OP_ANT = OPERACION.SUMAR;       break;
                    case R.id.b_menos: OP_ANT = OPERACION.RESTAR;      break;
                    case R.id.b_por:   OP_ANT = OPERACION.MULTIPLICAR; break;
                    case R.id.b_div:   OP_ANT = OPERACION.DIVIDIR;     break;
                    case R.id.b_igual: OP_ANT = OPERACION.IGUAL;       break;
                    case R.id.b_elevar: OP_ANT = OPERACION.ELEVAR;     break;
                    case R.id.b_raiz: OP_ANT = OPERACION.RAIZ;         break;
                }
                // tras acabar operación, se reinicializa operando2
                operando2_str = "";
                operando2 = 0.;
                punto = false;
                estado = ESTADOS.OPERACION; // estamos en estado OPERACION
                LastClickClear = false;
                break;

            case R.id.b_signo:
                acumulador = operar(acumulador, OPERACION.SIGNO, operando2);
                display.setText( miDoubleToString(acumulador) );
                operando2_str = "";
                operando2 = acumulador;
                LastClickClear = false;
                break;
            case R.id.clear:
                operando2 = operar(acumulador, OPERACION.BORRADO, operando2);
                display.setText( miDoubleToString(operando2) );
                break;
        }

    }



    /**
     * Devuelve el resultado de la operación entre dos operandos
     *
     * @param operando1 el primer operando double
     * @param operacion operación como valor enumerado: OPERACION.SUMAR, OPERACION.RESTAR, ...
     * @param operando2 el segundo operando double
     * @return operando1 OPERACION operando2
     *
     */

    private double operar (double operando1, OPERACION operacion, double operando2) {
        switch (operacion) {
            case SUMAR:       return operando1 + operando2;
            case RESTAR:      return operando1 - operando2;
            case MULTIPLICAR: return operando1 * operando2;
            case DIVIDIR:     return operando1 / operando2;
            case ELEVAR:      return Math.pow(operando1,operando2);
            case RAIZ:        return Math.sqrt(operando1);
            case IGUAL:
                if (estado == ESTADOS.NUMERO) {
                    return ((operando2_str.equals("")) ? operando1 : operando2); // Si operando2_str=="",
                } else {
                    return operando1;
                }
            case SIGNO:
                if (estado == ESTADOS.NUMERO) {
                    operando2 = -operando2;
                    return operando2;
                } else if (estado == ESTADOS.OPERACION){
                    operando1 = -operando1;
                    return operando1;
                }
            case BORRADO:
                if (estado == ESTADOS.NUMERO){
                    if (LastClickClear == false){
                        operando2_str = "";
                        operando2 = 0.;
                        LastClickClear = true;
                        return operando2;
                    } else {
                        aINIC();
                        break;
                    }
                } else if (estado == ESTADOS.OPERACION) {
                    aINIC();
                    break;
                }
        }
        return 0.; // indiferente
    }

    /**
     * Convierte a double un String
     *
     * @param numero_string String que representa a un número
     * @return un double desde un String
     */
    private double miStringToDouble(String numero_string) {
        return Double.parseDouble(numero_string);
    }

    /**
     * Devuelve un String con formato desde un double
     *
     * @param numero_double double a convertir a String
     * @return String convertido del parámetro
     */
    private String miDoubleToString(double numero_double) {
        return (df.format(numero_double));
    }

}