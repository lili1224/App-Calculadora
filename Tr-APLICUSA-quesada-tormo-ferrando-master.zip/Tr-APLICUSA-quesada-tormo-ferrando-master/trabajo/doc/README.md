<!-- markdownlint-disable MD033 -->

<div style="background-color:white; color:black">

<h3 align="center">Aplicaciones y Usabilidad</h3>

<img src="../figuras/UPVcolor300.png" align="left" height="40">
<img src="../figuras/DCOM.png" align="right" height="40">

<img src="../figuras/Teleco.png"       align="left" style="clear:left; padding-top:10px" height="40">

<img src="../figuras/GTDM.png"       align="right" style="clear:right; padding-top: 10px" height="40">

<br></br>

<h1 align="center"><b>Trabajo de asignatura de  Aplicaciones y Usabilidad</b></h1>


<h4 align="center"><b>Lucía Quesada Moreno</b><br>
<b>Toni Tormo Pla</b><br>
<b>Carlos Ferrando Oltra</b>
</h4>

<h3 align="center">Grado en Tecnología Digital y Multimedia</h3>
<h3 align="center">ETSIT-UPV</h3>

### Índice

<div style="text-align:center; font-size:24px">Calculadora</div>

1. <a href="#intro">**Introducción**</a>  
2. <a href="#basica">**Calculadora básica**</a>    
3. <a href="#cientifica">**Calculadora científica**</a>    
4. <a href="#conc">**Conclusiones**</a>     


<div id="intro"></div>

# [1. Introducción](#Índice)

Mediante esta práctica y los recursos obtenidos en el enunciado proporcionado, hemos implementado una calculadora básica para nuestro dispositivo móvil. De esta manera, cumplimos el objetivo principal del proyecto. 

Por otra parte, para ampliar la aplicación y hacerla más completa, nuestro grupo se ha puesto como obetivo implementar varias funciones de una calculadora científica. En esta calculadora ampliada, podemos realizar operaciones como una raíz cuadrada básica y elevación a un exponente cualquiera.

Para poder explicar todo el proceso realizado para la elaboración de la aplicación, dividiremos los puntos expuestos en el apartado 4 del enunciado en dos partes: **Calculadora básica** y **Calculadora científica**.

<div id='basica'></div>

# [2. Calculadora básica](#Índice)

Antes de empezar aa implementar correctamente los botones de la calculadora básica, vamos a configurar el funcionamiento de la aplicación a nivel de orientación (verticau u horizontal) y otras características que iremos viendo a lo largo de este apartado y el siguiente apartado.

Empecemos por el apartado **4.1.Control de la orientación** del enunciado, el cual nos explica como hacer que la aplicación no se reinicie cuando se cambie la orientación de vertical a horizontal y viceversa. Para solucionar este problema, vamos a implementar la siguiente línea de código en la función **onCreate()**:

    
    setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_PORTRAIT);
    

A continuación, vamos a solucionar el siguiente problema que se presenta en el apartado **4.2.Control del punto decimal**. El problema expuesto se debe a que, como nos podemos fijar en la aplicación cuando la iniciamos, el elemento inical es 0.:

![Figura 1.1.Elemento inicial clculadora](../figuras/Elemento_inicial_edit.jpg)

El punto que acompaña al cero se interprenta en la calculadora como la coma flotante para representar los decimales. Hay que tener en cuenta que, cuando el usuario inroduce un número en la calculadora, puede introducir manualmente un punto para introducir un número decimal y poder realizar operaciones más tarde. De esta manera, se presenta el problema principal de este apartado, se trata de que ahora tenemos dos comas decimales representadas en la calculadora, produciendo un error en el procesamiento del número en cuestión. 

Para poder solucionar este problema, vamos a realizar una conversión de la coma flotante inicial para así poder introducir los números decimiales manualmente sin que aparezcan errores. El código propuesto en nuestra aplicación, el cual hemos introducido en la función **alPulsarTecla()**, es el siguiente:


    case R.id.b_punto:
        if (punto == false){
            punto = true;
                if (operando2_str.equals("")){
                    operando2_str = "0";
                }
            } else {
                return;
            } 


Como podemos observar, si pulsamos la tecla **punto**, realizamos una conversión de elemento **double** a elemento **string** para que no forme parte del núemro introducido y al operar con éste la calculadora *no lo tenga en cuenta*.

Seguimos a continuación con el siguiente apartado, **4.3.Operativa de =**, el cual se nos presenta como funciona el operador en cuestión y como se implementa con el **acumulador**. En el enunciado proporcionado, se nos explica que *tras pulsar el signo igual, al igual que con el resto de operaciones generales, se realiza la operacion_anterior mostrando en pantalla el resultado del acumulador.*
Al abrir la aplicación dada sin modificar nada ni implementar nada inicialmente, nos damos cuenta que el **acumulador** funciona tal como se explica en el enunciado, pero nos damos cuenta que la estructura para realizar operaciones en la calculadora es la siguiente:

**Operador1/Acumulador - Operación (botón) - Operador2 - Signo igual**

Además, el signo igual debe de cumplir las siguientes condiciones:

**1.** Si no hay nada, es decir, si tras = viene una operación general, entonces el resultado de la operación = es el operando1, es decir, el propio acumulador.

**2.** Si hay un número entre = y el siguiente operador, el resultado de la operación = es el operando2.

**3.** Dos (o más) = consecutivos. Encaja con el comportamiento del caso 1.

Para que el operador funcione correctamente respetando los casos explicador anteriormente, implementamos el siguiente fragmento de código que podemos encontrar en la función **operar()**:


    case IGUAL:
        if (estado == ESTADOS.NUMERO) {
            return ((operando2_str.equals("")) ? operando1 : operando2); // Si operando2_str=="",
        } else {
            return operando1;
        }


Pasamos al apartado **4.4.Cambio de operación aritmética**, el cual se nos presenta que si pulsamos a diferentes operaciones entes de escoger el segundo operador, se realizará la última operación escogida. Por ejemplo, como operador 1 escogemos como valor 3, ahora debemos escoger el tipo de operación que queramos realizar pero nos equivocamos y pulsamos suma en lugar de multiplicación. Si pulsamos después al botón de la multiplicación y luego escogemos el valor del operador 2, se realizará la multiplicación y no la suma que habíamos pulsado al principio.

Teniendo en cuenta el funcionamiento de los botónes, nos fijamos en la función **alPulsarTecla()**, y nos fijamos que al final de los casos de los botones de operaciones tenemos el siguiente fragmento de código:


    if (OP_ANT != OPERACION.IGUAL){
        OP_ANT = OPERACION.IGUAL;
    } 


Este fragmento de código, que además veremos más adelante en otros casos del mismo switch, hace posible que solo se realice la operación que se ha seleccionado al final, antes de escoger el valor del operador 2.

A continuación, vamos a terminar de configurar los botones que no funcionan en la calculadora dada inicialmente. Comencemos por el botón **+/-** explicado en el apartado **4.5.Cambio de signo +/-**.  Su funcionamiento es muy intuitivo, si el valor introducido o resultante de una operacion ya realizada es positivo, tras pulsar el botón **+/-** se convertira en un valor negativo, y viceversa. 

El código que hemos empleado e introducido en la función **operar()** es el siguiente:

     case SIGNO:
        if (estado == ESTADOS.NUMERO) {
            operando2 = -operando2;
            return operando2;
        } else if (estado == ESTADOS.OPERACION){
            operando1 = -operando1;
            return operando1;
        }

A continuación, configuraremos el otro botón no funcional de la calculadora, el de borrado **C**. Si leemos el apartado **4.6.Tecla C (clear)** observamos que este botón tiene dos funciones dependiendo de cuantas veces es pulsado:

**1.** Si estamos en el estado **NÚMERO**, entonces deberían inicializarse tanto operando2_str como operando2, mostrando el valor del recurso String cero; si se vuelve a pulsar una segunda vez consecutiva, entonces se debe volver al estado **INIC**.

**2.** Si estamos en el estado **OPERACIÓN**, entonces se vuelve al estado **INIC**.

El código implementado en la función **operar()** es el siguiente:

    case BORRADO:
        if (estado == ESTADOS.NUMERO){
            if (LastClickClear == false){
                operando2_str = "";
                operando2 = 0.;
                LastClickClear = true;
                return operando2;
            } else {
                aINIC();
                break;
            }
        } else if (estado == ESTADOS.OPERACION) {
            aINIC();
            break;
    }

De esta manera, cada vez que pulsemos el botón **C**, dependiendo del estado en el que se encuentre la calculadora realizará una función u otra.

A partir de aquí, mejoramos el display de los elementos de la calculadora con los elemntos ya dados en el archivo **MainActivity.java** inicialmente.

Finalmente, tras terminar de implementar la calculadora básica y comprobar que funcione correctamente, creamos el logo de la aplicación:

![Figura 1.2.Logo clculadora](../Practica-CalculadoraAndroid/app/src/main/calculadora_logo-playstore.png)

Además, respetando los colores del logo propuesto, hemos cambiado la interfaz de la calculadora cambiando los colores por defecto y añadiendo imágenes extras que explicareos en el siguinete apartado.


<div id='cientifica'></div>

# [3. Calculadora científica](#Índice)

Una vez tengamos la calculadora básica implementada completamente y sin ningún error, hemos pensado en implementar dos operaciones más correspondientes a una calculadora científica y que no sean muy complejas de implementar. 

Para poder realizar las operaciones propuestas (elevación de un exponente y raíz cuadrada) hemos empleado el paquete de Java **math**, que se puede ver al principio del código. 

Fijándonos en como se han creado los botones de las operaciones básicas, creamos dos botones más y dejamos la distribución de la calculadora de la siguiente manera:

![Figura 1.3.Distribución clculadora](../figuras/distribucion.jpg)

Una vez configurados los botones para que así salgan representados en la aplicación, los configuramos para que funciones correctamente en la función **operar()** junto con el resto de operaciones:

    case ELEVAR:      return Math.pow(operando1,operando2);
    case RAIZ:        return Math.sqrt(operando1);


Finalmente, una vez tengamos todos los botones de la aplicación funcionales y sin ningún tipo de error, terminamos de personalizar la aplicación respetando los colores del logo creado. De esta manera, los colores de los botones para operar y los botones que contienen los números son de colores distintos. También hemos cambiado el color del fondo de la aplicación y cambiado la fuente del texto que emplea la aplicación siguiendo las indicaciones propuestas en el apartado **4.8.Fuente del display**. una vez realizados los cambios que hemos visto oportunos, la aplicación ha quedado de la siguiente manera:

![Figura 1.4.Interfaz final clculadora](../figuras/interfaz.jpg)


<div id='conc'></div>

# [4. Conclusiones](#Índice)

Finalmente, y para concluir el trabajo, cabe recalcar que nuestro grupo ha aprendido mucho mediante la realización de esta aplicación interactiva, poniendo así en práctica la teoría dada en clase. Así, hemos creado una aplicación a nuestro gusto y a la vez hemos aprendido nuevas técnicas y aplicaciones que contiene Android Studio. Por otro lado, gracias a que hemos tenido que emplear la herramienta de Git Hub para la elaboración del proyecto final, hemos refrescado lo visto en el taller correspondiente y además nos hemos familiarizado con la herramienta.
